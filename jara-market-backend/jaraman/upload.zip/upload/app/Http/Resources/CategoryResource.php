<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id'            => $this->id,
            'name'          => $this->name,
            'description'   => $this->description,
            'ingredients'   => ProductResource::collection($this->whenLoaded('ingredients')),
            'products'      => ProductResource::collection($this->whenLoaded('products')),
            'created_at'    => $this->created_at->diffForHumans(),
        ];
    }
}
